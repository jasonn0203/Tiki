﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Tiki.Models
{
    public class DataModel
    {
        public static string connectionString = "workstation id=tikidapm.mssql.somee.com;packet size=4096;user id=jsnhn11_SQLLogin_1;pwd=pf2h254zry;data source=tikidapm.mssql.somee.com;persist security info=False;initial catalog=tikidapm";


        public string xulydulieu(string text)
        {
            String s = text.Replace(",", "&44;");
            s = s.Replace("\"", "&34;");
            s = s.Replace("'", "&39;");
            return s;

        }


        public ArrayList get(String sql)
        {
            ArrayList dataList = new ArrayList();

            // Khai báo SqlConnection nhưng không mở kết nối ngay lúc này
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Khai báo SqlCommand với kết nối đã được thiết lập
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    // Mở kết nối trước khi thực hiện truy vấn
                    connection.Open();

                    // Sử dụng SqlDataReader trong phạm vi này
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ArrayList row = new ArrayList();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(xulydulieu(reader.GetValue(i).ToString()));
                            }
                            dataList.Add(row);
                        }
                    }

                    // Kết thúc truy vấn, đóng kết nối
                    connection.Close();
                }
            }

            return dataList;
        }


    }
}