﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tiki.Models;

namespace Tiki.Controllers
{
    public class SanPhamAPIController : Controller
    {
        // GET: SanPhamAPI
        public JsonResult Index()
        {
            DataModel db = new DataModel();
            ArrayList array = db.get("EXEC LAYTTSANPHAM;");
            return Json(array, JsonRequestBehavior.AllowGet);

        }


    }
}